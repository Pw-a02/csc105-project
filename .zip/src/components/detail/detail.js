import React from "react";
import Map from "../Compare/api";
import { Link } from "react-router-dom";
import "./detail.css";

const DetailContent = ({ name, img, price, detail, option }) => {
  return (
    <div className="Detail-content">
      <h2>{name}</h2>
      <img src={img} />
      <div className="Detail-form">
        <label>Price: {price}/night</label>
        <label>detail: {detail}</label>
        <label>option: {option}</label>
      </div>
      <div className="mapp">
        <Map />
      </div>
      <div className="Detail-btn">
        <Link to="#">
          <button>Booking</button>
        </Link>
      </div>
    </div>
  );
};

export default DetailContent;
