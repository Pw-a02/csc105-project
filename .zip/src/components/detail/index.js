import React from "react";
import DetailContent from "./detail";
import detail1 from "../../images/detail2.jpg";

const Details = () => {
  return (
    <div className="Detail-container">
      <div className="Detail-container1">
        <DetailContent
          name="Novotel"
          img={detail1}
          price={999}
          detail="available"
          option="include breakfast"
        />
      </div>
    </div>
  );
};

export default Details;
