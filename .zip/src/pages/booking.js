import React from "react";
import Booking from "../components/Booking";
import Navbar from "../components/Navbar";

const BookingPage = () => {
  return (
    <>
      <Booking />
    </>
  );
};

export default BookingPage;
