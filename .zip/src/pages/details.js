import React from "react";
import Details from "../components/detail";

const DetailsPage = () => {
  return (
    <div>
      <Details />
    </div>
  );
};

export default DetailsPage;
