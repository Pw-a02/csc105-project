// import { Container } from '@material-ui/core';
import React from 'react';
import SignIn from '../components/Signin';

const SigninPage = () => {
    return (
        <>
            <SignIn />
        </>
    )
}

export default SigninPage
